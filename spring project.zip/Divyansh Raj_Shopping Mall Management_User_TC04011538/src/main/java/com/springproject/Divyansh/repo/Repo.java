package com.springproject.Divyansh.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springproject.Divyansh.entity.entity;

@Repository
public interface Repo extends JpaRepository<entity, Integer> {


}
