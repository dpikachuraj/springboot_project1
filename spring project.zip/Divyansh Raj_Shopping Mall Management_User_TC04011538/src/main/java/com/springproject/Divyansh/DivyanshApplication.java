package com.springproject.Divyansh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DivyanshApplication {

	public static void main(String[] args) {
		SpringApplication.run(DivyanshApplication.class, args);
	}

}
