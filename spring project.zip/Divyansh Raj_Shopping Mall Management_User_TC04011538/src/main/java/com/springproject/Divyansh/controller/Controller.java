package com.springproject.Divyansh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springproject.Divyansh.entity.entity;
import com.springproject.Divyansh.service.service;

@RestController
public class Controller {
@Autowired
service s;
	
	
	@RequestMapping("/user")
	public String user() {
		return "welcome";
	}
	
	@PostMapping("/add")
	public entity add(@RequestBody entity e) {
		
		return s.ad(e);
	}
	@GetMapping("/get/{id}")
	public entity getValues(@PathVariable Integer id) {
		return s.getdetails(id);
	}
	
	@PutMapping("/alter")
     public entity update(@RequestBody entity values) {
		
		return s.alter(values);
		
	}
	
	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable Integer id){
		return s.del(id);
	}

	@GetMapping("/records")
	public List<entity> all(){
		return s.records();
	}
}


