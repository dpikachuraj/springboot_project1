package com.springproject.Divyansh.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;


import com.springproject.Divyansh.entity.entity;
import com.springproject.Divyansh.repo.Repo;

@Service
public class service {
	@Autowired
	Repo r;
	
	
	public entity ad(entity y) {
		return r.save(y);
	}


	public entity getdetails(Integer id) {
		// TODO Auto-generated method stub
		Optional<entity> findById = r.findById(id);// optional objects are introduced in java 1.8 to avoid null pointer exception
		// if we type any id if the value is null then we will null pointer exception so to over come we using optional object
		
		//if the record avilable then it is stored in optional else it will return null
		if(findById.isPresent()) {
			return findById.get();
			}else {
				return null;
			}
	}


	public entity alter(entity values) {
		// TODO Auto-generated method stub
		return r.save(values);
	}


	public String del(Integer id) {
		entity d=r.findById(id).get();
    	r.delete(d);
    	return "deleted sucessfully";
	}


	public List<entity> records() {
		return r.findAll();
	}

}
