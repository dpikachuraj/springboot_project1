package com.springproject.Divyansh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DivyanshApplicationTests {

	@Test
	void contextLoads() {
	}

}
